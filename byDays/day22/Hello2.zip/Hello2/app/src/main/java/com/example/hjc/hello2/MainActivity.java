package com.example.hjc.hello2;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    String msg="MainActivity is :";


    private MyService.LoadBinder loadBinder;
    private ServiceConnection serviceConnection=new ServiceConnection(){
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            loadBinder=(MyService.LoadBinder)service;
            loadBinder.startLoad();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };


    /**
     *创建Activity 时调用此方法。必须实现此方法。
     * @param savedInstanceState 保存的Activity状态
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//向用户界面填充activity_main.xml的布局内容
        Log.v(msg, "onCreate,task id="+getTaskId()); //在Logcat中输出信息

        Button bt=(Button)findViewById(R.id.bt); //根据id找到这个button
        bt.setOnClickListener(new View.OnClickListener() {
            @Override   //设置该按钮的点击监听器，重写其点击时动作（onclick方法）
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"press",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.setClass(MainActivity.this, SecondActivity.class); //设置跳转的Activity
                startActivity(intent); //传入intent,启动活动
            }
        });

        Button bt4=findViewById(R.id.bt4);
        Button bt5=findViewById(R.id.bt5);
        bt4.setOnClickListener(this);
        bt5.setOnClickListener(this);

//        Log.v(msg,"verbose");
//        Log.d(msg,"debug");
//        Log.i(msg,"info");
//        Log.w(msg,"warning");
//        Log.e(msg,"error");

    }

    //注册点击事件
    public void onClick(View v){
        switch (v.getId()){
            //绑定服务
            case R.id.bt4:
                bindService(new Intent(this,MyService.class),serviceConnection,BIND_AUTO_CREATE);
                break;
            //解绑服务
            case R.id.bt5:
                boolean b=isServiceActive(this,"com.example.hjc.hello2.MyService");
                if(b){
                    unbindService(serviceConnection);
                }
                break;
            default:
                break;
        }
    }

    public boolean isServiceActive(Context context, String serviceName){
        // 校验服务是否还存在
        ActivityManager am = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> services = am.getRunningServices(100);
        for (ActivityManager.RunningServiceInfo info : services) {
            // 得到所有正在运行的服务的名称
            String name = info.service.getClassName();
            Log.d("当前运行的service:",name);
            if (serviceName.equals(name)) {
                return true;
            }
        }
        return false;
    }

    public void startService(View view){
        startService(new Intent(this,MyService.class));
    }

    public void stopService(View view) {
        stopService(new Intent(this, MyService.class));
        Log.v(msg,"stopService");
    }

    //当活动即将可见时调用
    @Override
    protected void onStart() {
        super.onStart();
        Log.v(msg, "onStart");
    }

    //当活动可见时调用
    @Override
    protected void onResume() {
        super.onResume();
        Log.v(msg, "onResume");
    }

    //当活动暂停时调用(此时另一个 Activity 位于屏幕前台并具有用户焦点)
    @Override
    protected void onPause() {
        super.onPause();
        Log.v(msg, "onPause");
    }

    //当活动不再可见时调用
    @Override
    protected void onStop() {
        super.onStop();
        Log.v(msg, "onStop");
    }

    //当活动被停止以后重新打开时调用
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v(msg, "onRestart");
    }

    //当活动将被销毁时调用
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(msg, "onDestroy");
    }

}
