package com.example.hjc.hello2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by hjc on 18-7-9.
 */

public class FourthActivity extends Activity implements View.OnClickListener,AdapterView.OnItemClickListener{
    String four="FourthActivity:";

    private String[] data={"方法","ff","ww","qq","ee","vv"};
    private ListView lv1;
    private ArrayAdapter<String> adt1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
        adt1=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        lv1=findViewById(R.id.list_view1);
        lv1.setAdapter(adt1);
        lv1.setOnItemClickListener(this);

        Button fr_bt1=findViewById(R.id.fr_bt1);
        fr_bt1.setOnClickListener(this);

        Button fr_bt2=findViewById(R.id.fr_bt2);
        fr_bt2.setOnClickListener(this);

        Button fr_bt3=findViewById(R.id.fr_bt3);
        fr_bt3.setOnClickListener(this);

        Button fr_bt4=findViewById(R.id.fr_bt4);
        fr_bt4.setOnClickListener(this);

        Button fr_bt5=findViewById(R.id.fr_bt5);
        fr_bt5.setOnClickListener(this);

        Log.d(four,"onCreate,Task id is "+getTaskId());
    }

    private int count=0;
    Handler handler=new Handler();
    private Runnable runTest=new RunTest();

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fr_bt1:
                Intent intent=new Intent(this,FifthActivity.class);
                startActivity(intent);
                break;
            case R.id.fr_bt2:
                try {
                    Log.d(four,"sleep");
                    Thread.sleep(15500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.fr_bt3:
                handler.postDelayed(runTest,1000);
                break;
            case R.id.fr_bt4:
                handler.removeCallbacks(runTest);
                break;
            case R.id.fr_bt5:
                startActivity(new Intent(this, SixthActivity.class));
                break;
            default:break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this, data[position], Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(runTest);
        super.onDestroy();
    }

    class RunTest implements Runnable {
        @Override
        public void run() {
            count++;
            data[0] = "child thread" + count;
            adt1.notifyDataSetChanged();
            //handler.postDelayed(this, 1000);
        }
    }
}
