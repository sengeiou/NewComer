package com.example.hjc.hello2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by hjc on 18-7-6.
 */

public class TestSqlHelper extends SQLiteOpenHelper{
    String sqlHelper="TestSqlHelper";

    //建表语句字符串形式，和MySql差不多，有自增功能
    private static final String CREATE_CAR="create table Car(id integer primary key autoincrement,owner text,price real,seats integer)";
    private static final String CREATE_KEY="create table KEY(id integer primary key autoincrement,name text,weight real)";

    //构造方法(上下文,数据库名,建立游标的工厂,版本号)
    public TestSqlHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //执行sql语句
        db.execSQL(CREATE_CAR);
        Log.d(sqlHelper,"已创建");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(CREATE_KEY);
        Log.d(sqlHelper,"已升级");
    }
}
