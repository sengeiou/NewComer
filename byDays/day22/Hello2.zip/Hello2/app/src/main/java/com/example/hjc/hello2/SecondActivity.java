package com.example.hjc.hello2;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by hjc on 18-6-30.
 */

public class SecondActivity extends AppCompatActivity implements View.OnClickListener{

    String msg="SecondActivity: ";
    private NetChangeReceiver netChangeReceiver;
    private LocalReceiver localReceiver;
    private IntentFilter intentFilter;
    private IntentFilter localIntentFilter;

    private LocalBroadcastManager localBroadcastManager;



    /**
     * 项目中任何添加的资源都会在R文件中生成一个资源id
     * R文件的位置是
     * /home/hjc/AndroidStudioProjects/Hello2/app/build/generated/source/r/debug/
     * 点进去可以看到：这个类里定义了很多int常量(包括之前定义的activity_second,activity_second,bt)
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        intentFilter=new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE"); //手动创建一个IntentFilter
        netChangeReceiver=new NetChangeReceiver();
        registerReceiver(netChangeReceiver,intentFilter); //注册这个receiver
        Button sc_bt=findViewById(R.id.sc_bt);


        //本地广播
        localBroadcastManager=LocalBroadcastManager.getInstance(this);
        localIntentFilter=new IntentFilter();
        localIntentFilter.addAction("com.example.hjc.hello.LocalBroadCast");
        localReceiver=new LocalReceiver();
        localBroadcastManager.registerReceiver(localReceiver,localIntentFilter); //本地监听器
        Button sc_bt2=findViewById(R.id.sc_bt2);


        //隐式intent
        Button sc_bt3=findViewById(R.id.sc_bt3);
        //启动电话10086
        Button sc_bt4=findViewById(R.id.sc_bt4);
        //启动其他程序
        Button sc_bt5=findViewById(R.id.sc_bt5);
        //以startActivityForResult启动
        Button sc_bt6=findViewById(R.id.sc_bt6);

        sc_bt.setOnClickListener(this);
        sc_bt2.setOnClickListener(this);
        sc_bt3.setOnClickListener(this);
        sc_bt4.setOnClickListener(this);
        sc_bt5.setOnClickListener(this);
        sc_bt6.setOnClickListener(this);


        Log.d(msg, "onCreate,task id="+getTaskId());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sc_bt:
                //发送标准广播
                sendBroadcast(new Intent("com.example.hjc.hello.BroadCast"));
                break;
            case R.id.sc_bt2:
                //发送本地广播
                localBroadcastManager.sendBroadcast(new Intent("com.example.hjc.hello.LocalBroadCast"));
                break;
            case R.id.sc_bt3:
                //隐式intent，并添加分类
                Intent intent=new Intent("android.intent.action.ACTION_START");
                intent.putExtra("hello","world"); //添加额外信息，可用于传递数据
                intent.addCategory("android.intent.category.ONE");
                startActivity(intent);
                break;
            case R.id.sc_bt4:
                //启动电话，并输入号码10086，先判断是否有权限打电话
                if(ContextCompat.checkSelfPermission(SecondActivity.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},1);
                }else{
                    Log.d(msg,"打电话权限已授权");
                    call();
                }
                break;
            case R.id.sc_bt5:
                //启动计算器
                ComponentName cn=new ComponentName("com.android.hjc","com.android.hjc.Calculator");
                Intent intent5=new Intent();
                intent5.setComponent(cn);
                startActivity(intent5);
                break;
            case R.id.sc_bt6:
                Intent intent6=new Intent(this,ThirdActivity.class);
                intent6.putExtra("hello","world6");
                Bundle bundle=new Bundle();
                bundle.putString("1","one");
                intent6.putExtra("bb",bundle);
                intent6.putExtras(bundle);
                startActivityForResult(intent6,3);
                break;
            default:break;
        }
    }

    //调用完requestPermissions方法后，会弹出选择框给用户，用户无论同意与否都会回调onRequestPermissionsResult方法
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case 1:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    call();
                }else{
                    Toast.makeText(this,"permission denied",Toast.LENGTH_SHORT).show();
                }
                break;
            default:break;
        }
    }

    //打电话
    public void call(){
        try{
            Intent intent4=new Intent(Intent.ACTION_DIAL);
            intent4.setData(Uri.parse("tel:10086"));
            startActivity(intent4);
        }catch (SecurityException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode){
            case 3:
                if(resultCode==RESULT_OK){
                    Log.d(msg,data.getStringExtra("third"));
                }
                break;
            default:break;
        }
    }

    //当活动即将可见时调用
    @Override
    protected void onStart() {
        super.onStart();
        Log.v(msg, "onStart");
    }

    //当活动可见时调用
    @Override
    protected void onResume() {
        super.onResume();
        Log.v(msg, "onResume");
    }

    //当活动暂停时调用(此时另一个 Activity 位于屏幕前台并具有用户焦点)
    @Override
    protected void onPause() {
        super.onPause();
        Log.v(msg, "onPause");
    }

    //当活动不再可见时调用
    @Override
    protected void onStop() {
        super.onStop();
        Log.v(msg, "onStop");
    }

    //当活动被停止以后重新打开时调用
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v(msg, "onRestart");
    }

    //当活动将被销毁时调用
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(netChangeReceiver); //必须要取消注册
        localBroadcastManager.unregisterReceiver(localReceiver); //取消注册本地监听
        Log.v(msg, "onDestroy");
    }

    /**
     *
     */
    class NetChangeReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context,"network changed",Toast.LENGTH_SHORT).show();
            Log.v("NetChangeReceiver","is onReceive");
        }
    }

    class LocalReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context,"Local Received",Toast.LENGTH_SHORT).show();
            Log.v("LocalReceiver","is onReceive");
        }
    }
}
