package com.example.hjc.hello2;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.TextView;


/**
 * Created by hjc on 18-7-9.
 */

public class FifthActivity extends Activity{
    String five="FifthActivity:";

    private Runnable runnable;

    private final int[] COLOR_ARRAY={Color.BLACK,Color.WHITE};
    private int index=0,count=0;
    private TextView textView;
    private Handler handler=new Handler();

    private int[] testX={1,2,3,4,5};
    private int[] textY={2,4,8,16,32};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        textView=new TextView(this);
        setContentView(textView);
        Log.d(five,"task id="+getTaskId());
        runnable=new Runnable() {
            @Override
            public void run() {
                textView.setBackgroundColor(COLOR_ARRAY[index]);
                index=1-index;
                count++;
                setBackground();
            }
        };
        setBackground();


    }


    public void setBackground(){
        if(count>3){
            return;
        }
        handler.postDelayed(runnable,1000);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(runnable);
        super.onDestroy();
    }
}
