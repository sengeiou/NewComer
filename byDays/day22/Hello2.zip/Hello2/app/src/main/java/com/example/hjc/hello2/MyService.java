package com.example.hjc.hello2;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MyService extends Service {
    String msg="MyService is ";
    private LoadBinder loadBinder=new LoadBinder();

    /**
     *必须实现该方法。其他组件想要通过bindService()来绑定服务时，系统调用该方法。
     *返回IBinder对象，提供一个接口，以便与服务通信。返回null,表示不绑定。
     */
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service
        Log.v(msg,"onBind");
        return loadBinder;
    }

    /**
     *通过unbindService()解除所有客户端绑定时调用
     */
    @Override
    public boolean onUnbind(Intent intent) {
        Log.v(msg,"onUnbind");
        return super.onUnbind(intent);
    }

    //当新的客户端与服务连接，且此前它已经通过onUnbind(Intent)通知断开连接时，系统调用该方法。
    @Override
    public void onRebind(Intent intent) {
        Log.v(msg,"onRebind");
        super.onRebind(intent);
    }

    //服务创建时调用
    @Override
    public void onCreate() {
        Log.v(msg,"onCreate");
        super.onCreate();
    }

    /**
     * 其他组件(如活动)通过调用startService()来请求启动服务时，系统调用该方法。
     * 工作完成时通过stopSelf()或者stopService()方法来停止服务。
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this,"service is starting",Toast.LENGTH_LONG).show();
        Log.v(msg,"onStartCommand");
        return START_STICKY;
    }

    //当服务不再有用或者被销毁时，系统调用该方法。
    @Override
    public void onDestroy() {
        Toast.makeText(this,"service is destroying",Toast.LENGTH_LONG).show();
        Log.v(msg,"onDestroy");
        super.onDestroy();
    }


    class LoadBinder extends Binder{
        public void startLoad(){
            Log.d(msg,"loading file");
        }
    }
}
