package com.example.hjc.hello2;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * Created by hjc on 18-7-2.
 */

public class MyProvider extends ContentProvider {

    /**
     * 创建时调用，返回true代表初始化成功，false代表失败
     * @return
     */
    @Override
    public boolean onCreate() {
        return false;
    }

    /**
     * Uri uri=Uri.parse("content://com.example.hjc/emp");Uri的形式
     * 查询函数 query(uri,new String[]{"ename"},"salary>?","5000","salary")
     * 等同 select ename from emp where salary>500 order by salary
     * @param uri 确定查哪张表
     * @param projection 确定查哪几列
     * @param selection 约束的参数
     * @param selectionArgs 约束的参数值
     * @param sortOrder 排序的参数
     * @return
     */
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        return null;
    }

    /**
     * @param uri
     * @return 返回一个MIME类型的字符串
     */
    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    /**
     * @param uri 哪张表
     * @param values 需要插入的数据的包装对象
     * @return
     */
    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    /**
     * @param uri 哪张表
     * @param selection 删除的约束参数
     * @param selectionArgs 删除的约束参数的值
     * @return
     */
    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    /**
     * @param uri 哪张表
     * @param values 需要更新的数据的包装对象
     * @param selection 更新的约束参数
     * @param selectionArgs 更新的约束参数值
     * @return
     */
    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
