package com.example.hjc.hello2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;

/**
 * Created by hjc on 18-7-23.
 */

public class SixthActivity extends FragmentActivity implements View.OnClickListener{

    private int index=1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sixth);

        Button frag_bt=findViewById(R.id.frag_bt1);
        frag_bt.setOnClickListener(this);

        replace(new RightFragment());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.frag_bt1:
                Fragment[] fragments=new Fragment[]{new RightFragment(),new RightFragment2()};
                replace(fragments[index]);
                index=1-index;
                break;
            default:
                break;
        }
    }

    private void replace(Fragment fragment){
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.right_fragment,fragment);
        fragmentTransaction.commit();
    }

}
