package com.example.hjc.hello2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by hjc on 18-7-2.
 */

public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context,"changed",Toast.LENGTH_SHORT).show();
        abortBroadcast();
        Log.v("MyReceiver","is onReceive");
    }
}
