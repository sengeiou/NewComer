package com.example.hjc.hello2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * Created by hjc on 18-7-4.
 */

public class ThirdActivity extends Activity implements View.OnClickListener{

    private EditText th_et;
    private EditText th_et2;
    private EditText th_et3;
    private String third="ThirdActivity:";
    private TestSqlHelper testSqlHelper=new TestSqlHelper(this,"Car.db",null,2);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        Intent intent=getIntent();


        Bundle bundle=intent.getExtras();
        String data=null;
        String hello=null;
        String data2=null;
        if(bundle!=null){
            data=bundle.getString("1");
            hello=intent.getStringExtra("hello");
            Bundle b1=intent.getBundleExtra("bb");
            if(b1!=null){
                data2=b1.getString("1");
            }
        }


        Button th_bt1=findViewById(R.id.th_bt1);
        th_bt1.setOnClickListener(this);

        th_et=findViewById(R.id.th_et);
        if(savedInstanceState!=null){
            Log.d("savedInstanceState:","非空");
            //String text=savedInstanceState.getString("text");
            th_et.setText("调用了");
        }
//        th_et.addTextChangedListener(new TextWatcher() {
//            String txt="TextWatcher:";
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//                Log.d(txt,"改变前");
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                //Log.d(txt,"改变时");
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                Log.d(txt,"改变后");
//            }
//        });
        th_et2=findViewById(R.id.th_et2);
        String text2="";
        if((text2=load())!=null){
            th_et2.setText(text2);
        }

        //使用SharedPerference保存按钮
        Button th_bt2=findViewById(R.id.th_bt2);
        th_bt2.setOnClickListener(this);
        //从SharedPreferences恢复
        Button th_bt3=findViewById(R.id.th_bt3);
        th_bt3.setOnClickListener(this);
        //数据库创建
        Button th_bt4=findViewById(R.id.th_bt4);
        th_bt4.setOnClickListener(this);
        //insert
        Button th_bt5=findViewById(R.id.th_bt5);
        th_bt5.setOnClickListener(this);
        //delete
        Button th_bt6=findViewById(R.id.th_bt6);
        th_bt6.setOnClickListener(this);
        //update
        Button th_bt7=findViewById(R.id.th_bt7);
        th_bt7.setOnClickListener(this);
        //query
        Button th_bt8=findViewById(R.id.th_bt8);
        th_bt8.setOnClickListener(this);
        //进入第4个活动
        Button th_bt9=findViewById(R.id.th_bt9);
        th_bt9.setOnClickListener(this);

        //输入框3
        th_et3=findViewById(R.id.th_et3);

        Log.d("ThirdActivity",hello+",data:"+data+",data2:"+data2+",task id="+getTaskId());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.th_bt1:
                Intent intent=new Intent();
                intent.putExtra("third","返回");
                setResult(RESULT_OK,intent);
                finish();
                break;
            case R.id.th_bt2:
                SharedPreferences sp=getSharedPreferences("sharedPerfer",MODE_PRIVATE);
                SharedPreferences.Editor ed=sp.edit();
                ed.putInt("1",1);
                ed.putBoolean("true",true);
                ed.putString("face","面");
                ed.putString("text",th_et3.getText().toString());
                ed.apply();
                break;
            case R.id.th_bt3:
                SharedPreferences sp1=getSharedPreferences("sharedPerfer",MODE_PRIVATE);
                String text=sp1.getString("text","nothing");
                th_et3.setText(text);
                break;
            case R.id.th_bt4:
                createDataBase();
                break;
            case R.id.th_bt5:
                insert();
                break;
            case R.id.th_bt6:
                delete();
                break;
            case R.id.th_bt7:
                update();
                break;
            case R.id.th_bt8:
                query();
                break;
            case R.id.th_bt9:
                Intent intent4=new Intent(ThirdActivity.this,FourthActivity.class);
                startActivity(intent4);
                break;
            default:break;
        }
    }

    //插入
    public void insert(){
        SQLiteDatabase database=testSqlHelper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("owner","mike");
        cv.put("price",10.2);
        cv.put("seats",5);
        database.insert("Car",null,cv);
        cv.clear();
        cv.put("owner","don");
        cv.put("price",30.2);
        cv.put("seats",8);
        database.insert("Car",null,cv);
    }

    //删除
    public void delete(){
        Log.d(third,"进入delete");
        SQLiteDatabase database=testSqlHelper.getWritableDatabase();
        database.delete("Car","price between ? and ?",new String[]{"10","11"});
    }

    //更新
    public void update(){
        SQLiteDatabase database=testSqlHelper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("price",8.6);
        database.update("Car",cv,"price>?",new String[]{"25"});
    }

    //查询
    public void query(){
        SQLiteDatabase database=testSqlHelper.getWritableDatabase();
        Cursor cursor=database.query("Car",null,null,null,null,null,null);
        Log.d(third,"id的index"+String.valueOf(cursor.getColumnIndex("id")));
        if(cursor.moveToFirst()){
            do{
                int id=cursor.getInt(0);
                String owner=cursor.getString(1);
                double price=cursor.getDouble(2);
                int seats=cursor.getInt(3);
                Log.d(third,"query,id="+id+",owner="+owner+",price="+price+",seats="+seats);
            }while(cursor.moveToNext());
        }
        cursor.close();
    }

    //创建数据库
    public void createDataBase(){
        //testSqlHelper=new TestSqlHelper(this,"Car.db",null,1);
        testSqlHelper.getWritableDatabase();
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent();
        intent.putExtra("third","返回");
        setResult(RESULT_OK,intent);
        finish();
    }

    //保存临时数据
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        String text="文本保存";
        outState.putString("text",text);
        Log.d(third,"进入onSaveInstanceState，输入框："+text);
    }

    //恢复数据
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if(savedInstanceState!=null){
            Log.d("onRestoreInstanceState:","非空");
            //String text=savedInstanceState.getString("text");
            th_et.setText("调用了");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(third,"destroy"+th_et2.getText().toString());
        save(th_et2.getText().toString());
    }

    //java-IO流操作，存储到data
    public void save(String s){
        try{
            FileOutputStream out=null;
            BufferedWriter bw=null;
            try{
                out=openFileOutput("data", Context.MODE_PRIVATE);
                bw=new BufferedWriter(new OutputStreamWriter(out));
                bw.write(s);
            }finally {
                if(bw!=null){
                    bw.close();
                }
                if(out!=null){
                    out.close();
                }
            }
        }catch (IOException e){
            Log.e("ThirdActivity:","IOException");
        }
    }

    //java-IO流操作-从data读取数据
    public String load(){
        StringBuilder content=new StringBuilder();
        try{
            FileInputStream in=null;
            BufferedReader br=null;
            try{
                in=openFileInput("data");
                br=new BufferedReader(new InputStreamReader(in));
                String line="";
                while((line=br.readLine())!=null){
                    content.append(line);
                }
            }finally {
                if(br!=null){
                    br.close();
                }
                if(in!=null){
                    in.close();
                }
            }
        }catch (FileNotFoundException e){
            Log.e("ThirdActivity:","FileNotFoundException");
            Toast.makeText(this,"文件未创建",Toast.LENGTH_SHORT).show();
        }catch (IOException e){
            Log.e("ThirdActivity:","IOException");
        }
        return content.toString();

    }
}
